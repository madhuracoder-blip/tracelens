'use strict';
// Offline tests: run against a local fake GitHub API (see mock-github.js). No network, no token needed.
// These prove the engine's logic and honesty guarantees. They do NOT prove behaviour against live GitHub.
const assert = require('assert');
const mock = require('./mock-github');

(async () => {
  const { server, url } = await mock.start();
  process.env.GITHUB_API_URL = url;
  delete process.env.GITHUB_TOKEN; delete process.env.ANTHROPIC_API_KEY;
  const { investigate } = require('../lib/analyze');
  const { parseRepoInput } = require('../lib/github');
  const { extractSignals } = require('../lib/signals');

  let passed = 0;
  const t = async (name, fn) => { try { await fn(); passed++; console.log('  ok  ', name); } catch (e) { console.error('  FAIL', name, '\n      ', e.message); process.exitCode = 1; } };

  await t('parseRepoInput handles URLs, issue links and shorthand', () => {
    assert.deepStrictEqual(parseRepoInput('https://github.com/pallets/click'), { owner: 'pallets', repo: 'click', issueNumber: null, isPull: false });
    assert.strictEqual(parseRepoInput('https://github.com/pallets/click/issues/2246').issueNumber, 2246);
    assert.strictEqual(parseRepoInput('https://github.com/a/b.git').repo, 'b');
    assert.strictEqual(parseRepoInput('a/b').owner, 'a');
    assert.throws(() => parseRepoInput('not a repo'));
  });

  await t('extractSignals finds files, errors, identifiers and versions', () => {
    const s = extractSignals('Crash in `consume_value` at core.py\nTypeError: bad default\nworked in 7.1.2 but fails on 8.0.4');
    assert.ok(s.files.includes('core.py'));
    assert.ok(s.errors.some((e) => e.includes('TypeError')));
    assert.ok(s.identifiers.includes('consume_value'));
    assert.deepStrictEqual(s.versions.map((v) => v.version), ['7.1.2', '8.0.4']);
  });

  let r;
  await t('investigation ranks the commit that introduced the removed lines first', async () => {
    const steps = [];
    r = await investigate({ repoUrl: 'https://github.com/o/r', issueNumber: 7, description: 'TypeError in run()' }, (s) => steps.push(s));
    assert.strictEqual(r.meta.mode, 'fix-anchored');
    assert.strictEqual(r.fix.number, 9);
    assert.strictEqual(r.candidates[0].sha, mock.BAD_SHA);
    assert.ok(r.candidates[0].hasProvenance, 'top suspect should have verified provenance');
    assert.ok(r.candidates[0].matchedLines.some((l) => l.includes('compute_value')));
    assert.ok(steps.some((s) => s.status === 'done'));
  });

  await t('maintenance-only commit is not ranked above the real cause', () => {
    const noise = r.candidates.find((c) => c.sha === mock.NOISE_SHA);
    assert.ok(!noise || noise.rank > 1);
  });

  await t('honesty guarantees: no test is ever reported as run or passed', () => {
    assert.strictEqual(r.ledger.testsRun, 0);
    assert.strictEqual(r.ledger.testsPassed, 0);
    assert.strictEqual(r.reproTest.status, 'not_run');
    assert.ok(/NOT RUN/.test(r.reproTest.code));
    assert.ok(!/\bpassed\b/i.test(r.spoken.replace(/not run|nothing is confirmed/gi, '')) || /not/i.test(r.spoken));
  });

  await t('hypotheses are labelled unverified and rule-based without an API key', () => {
    assert.strictEqual(r.hypothesisSource, 'rule-based');
    r.candidates.forEach((c) => { assert.strictEqual(c.hypothesis.status, 'hypothesis'); });
  });

  await t('repro test uses the issue snippet for a Python repo', () => {
    assert.strictEqual(r.reproTest.framework, 'pytest');
    assert.ok(r.reproTest.code.includes('raise TypeError'));
  });

  await t('timeline is chronological and links to sources', () => {
    const ts = r.timeline.map((e) => +new Date(e.ts));
    assert.deepStrictEqual(ts, [...ts].sort((a, b) => a - b));
    assert.ok(r.timeline.every((e) => e.url && e.verified));
  });

  await t('unknown repo yields a clear error, not a crash', async () => {
    await assert.rejects(() => investigate({ repoUrl: 'https://github.com/x/nope', description: 'bug' }), /404|private|misspelled/);
  });

  server.close();
  console.log(`\n${passed} checks passed${process.exitCode ? ' (with failures above)' : ''}.`);
})();
