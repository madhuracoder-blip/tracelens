'use strict';
// A tiny fake GitHub API used ONLY by the automated tests (never by the real app).
// Scenario: issue #7 reports a TypeError. PR #9 fixed it by removing lines that commit "aaa1111" had added.
const http = require('http');

const FIX_SHA = 'f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1f1';
const BAD_SHA = 'a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1a1';
const NOISE_SHA = 'b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2b2';
const OLD_SHA = 'c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3c3';

const commit = (sha, date, message, files) => ({
  sha, html_url: `https://github.com/o/r/commit/${sha}`,
  commit: { message, author: { name: 'dev' }, committer: { date } },
  files,
});
const COMMITS = {
  [BAD_SHA]: commit(BAD_SHA, '2024-03-01T10:00:00Z', 'Speed up flag value handling', [
    { filename: 'src/app/core.py', additions: 3, deletions: 1, patch: '@@ -10,3 +10,5 @@\n-    value = x\n+    value = compute_value(x)\n+    if value is None:\n+        value = default_items.append(value)' },
  ]),
  [NOISE_SHA]: commit(NOISE_SHA, '2024-03-05T10:00:00Z', 'Bump version and update changelog', [
    { filename: 'CHANGES.md', additions: 2, deletions: 0, patch: '@@ -1,1 +1,3 @@\n+Version 1.2\n+Released' },
  ]),
  [OLD_SHA]: commit(OLD_SHA, '2023-01-01T10:00:00Z', 'Initial core module', [
    { filename: 'src/app/core.py', additions: 20, deletions: 0, patch: '@@ -0,0 +1,2 @@\n+def run():\n+    pass_through = True' },
  ]),
};

function route(url) {
  const p = url.pathname;
  if (p === '/repos/o/r') return { language: 'Python', default_branch: 'main' };
  if (p === '/repos/o/r/issues/7') return { number: 7, title: 'TypeError in run() when flag is unset', html_url: 'https://github.com/o/r/issues/7', state: 'closed', user: { login: 'reporter' }, created_at: '2024-04-01T00:00:00Z', closed_at: '2024-04-10T00:00:00Z',
    body: 'Calling run() raises a TypeError.\n\n```python\nraise TypeError("boom")\n```\n\nTraceback:\n  File "src/app/core.py", line 12, in run\nTypeError: bad default\n\nWorked in 1.0.' };
  if (p === '/repos/o/r/issues/7/comments') return [];
  if (p === '/repos/o/r/issues/7/timeline') return [{ event: 'cross-referenced', source: { issue: { number: 9, pull_request: {} } } }, { event: 'closed' }];
  if (p === '/repos/o/r/pulls/9') return { number: 9, merged_at: '2024-04-09T00:00:00Z', merge_commit_sha: FIX_SHA, title: 'Fix TypeError in run()', body: 'Fixes #7', html_url: 'https://github.com/o/r/pull/9' };
  if (p === '/repos/o/r/pulls/9/files') return [
    { filename: 'src/app/core.py', additions: 1, deletions: 2, patch: '@@ -10,5 +10,3 @@\n-    value = compute_value(x)\n-        value = default_items.append(value)\n+    value = safe_value(x)' },
    { filename: 'tests/test_core.py', additions: 5, deletions: 0, patch: '@@ -1 +1,5 @@\n+def test_run(): pass' },
  ];
  if (p === '/repos/o/r/git/trees/main') return { truncated: false, tree: [{ type: 'blob', path: 'src/app/core.py' }, { type: 'blob', path: 'tests/test_core.py' }, { type: 'blob', path: 'CHANGES.md' }] };
  if (p === '/repos/o/r/releases') return [];
  if (p === '/repos/o/r/commits') return [COMMITS[NOISE_SHA], COMMITS[BAD_SHA], COMMITS[OLD_SHA]].map((c) => ({ sha: c.sha, html_url: c.html_url, commit: c.commit }));
  const m = p.match(/^\/repos\/o\/r\/commits\/([0-9a-f]+)$/);
  if (m && COMMITS[m[1]]) return COMMITS[m[1]];
  return null;
}

function start(port = 0) {
  return new Promise((resolve) => {
    const s = http.createServer((req, res) => {
      const body = route(new URL(req.url, 'http://x'));
      res.writeHead(body ? 200 : 404, { 'Content-Type': 'application/json', 'x-ratelimit-remaining': '55', 'x-ratelimit-limit': '60' });
      res.end(JSON.stringify(body || { message: 'Not Found' }));
    });
    s.listen(port, '127.0.0.1', () => resolve({ server: s, url: `http://127.0.0.1:${s.address().port}` }));
  });
}
module.exports = { start, BAD_SHA, NOISE_SHA, FIX_SHA };
