# Demo flow

## Built-in demo: pallets/click #2246

A real, public issue: [pallets/click#2246](https://github.com/pallets/click/issues/2246), "Flags with `multiple=True` trigger `TypeError`". The reporter shows a `TypeError` raised from `Parameter.consume_value()` for an `is_flag=True, multiple=True` option, a snippet that reproduces it, and says it worked in Click 7.1.2 but fails in 8.0.4 and 8.1.2. The Click changelog lists a later fix ("Allowing `multiple=True` on flag options again, without requiring `default=()`", issues 2246, 2292, 2295, in 8.1.4).

The issue text, snippet and versions above were checked against the live pages. **What the ranking will show was not checked against the live GitHub API before this was written**, so run it once yourself before recording and describe what you actually see.

### Before you record

1. Put a `GITHUB_TOKEN` in `.env` (the unauthenticated 60/hour limit is easy to hit, and Click's history is long).
2. Run the demo once. Results are cached for an hour, so the second run is instant and uses no API calls.
3. Look at the top suspect's evidence. If it shows **VERIFIED: added N line(s) that the fix later removed**, that is your headline. If it only shows file/keyword evidence, say so honestly on camera ("a weaker lead, not proof"). That honesty *is* the product.

### Reliable Plan B: a repo you control (15 minutes)

Create a tiny public GitHub repo with a seeded bug so the story is guaranteed:

1. Commit 1: a small `calc.py` with a correct `average(nums)` function plus a README.
2. Commit 2: "Speed up average" that changes it to something broken for empty lists (e.g. divide by `len(nums) - 1`).
3. Commit 3: an unrelated docs change.
4. Open issue #1 with a snippet in a fenced ```python block that calls `average([])` and the resulting error.
5. Commit 4 with the message "Fix average, fixes #1" that restores the correct line (the issue closes with that commit), or open and merge a PR whose body says "Fixes #1".

Then paste `https://github.com/<you>/<repo>/issues/1` into TraceLens. Commit 2 should rank first with verified provenance.

## 2:30 video script (limit is 3:00)

| Time | Show | Say |
|---|---|---|
| 0:00 | Landing screen, "Simulated Alexa+ experience" pill visible | "Debugging starts with guessing. TraceLens is a conversational agent that shows its evidence and never pretends to know more than it does." |
| 0:15 | Click the mic (or type) `Alexa, investigate https://github.com/pallets/click` | "I talk to it like an assistant. It asks what's wrong." |
| 0:30 | Say/type the issue description, or `run the demo` | "It's reading a real public issue and real commits, live from GitHub." |
| 0:45 | Progress steps ticking | "It finds the fix, maps the report to files, walks history, and reads diffs." |
| 1:05 | Suspects tab: top suspect, green VERIFIED lines | "Green means observed in GitHub data, like this commit adding lines the fix later removed." |
| 1:25 | Amber hypothesis box | "Amber is a hypothesis. It's a plausible story, clearly labelled, not a finding." |
| 1:40 | Ask "why is number 1 first" (spoken answer) | "I can ask why, and it explains from the evidence." |
| 1:55 | Timeline tab | "A chronological timeline, every entry linked." |
| 2:10 | Repro test tab, NOT RUN badge, Ledger tab with "Tests executed: 0" | "It drafts a reproduction test, but it never runs code, so it will never claim a pass. You run it and record the outcome." |
| 2:25 | Title card | "TraceLens: evidence first." |

Avoid showing Amazon/Alexa logos or using music: the rules prohibit third-party trademarks and unlicensed music in the video.
