# Hackathon submission guide

Source for rules below: the official Devpost rules page, https://amazonappdev2026.devpost.com/rules, as read on Oct 23, 2026. **Re-read it yourself before submitting**; it is the authority, not this file.

## Deadline

**Oct 23, 2026, 12:00 PM Pacific (PDT) = Oct 24, 2026, 12:30 AM IST.** Submit with margin; Devpost forms and video processing take time.

## How TraceLens fits the Alexa+ track

The rules describe the Alexa+ track as a working Agent Skill or a self-hosted MCP server, and state that **a simulated Alexa+ experience in a web app is also allowed**. The simulation path is exempt from the "required technology must be imported and called" rule, but **the repo must include source code and the video must clearly show the simulated experience.**

TraceLens takes the simulation path:

* **Conversational, voice-capable interface**: a chat assistant with a status orb (idle / listening / thinking / speaking), speech input via the browser's speech recognition, spoken replies via speech synthesis, optional "Alexa," wake-phrase prefix, slot-filling dialogue (it asks for the repo, then the bug), and spoken follow-ups ("why is number 1 first", "read it aloud").
* **Agentic workflow**: a multi-step investigation (collect issue and commits, find the fix, walk history, read diffs, rank suspects, draft a test) streamed to the conversation as live progress. The rules call out agentic workflows as favored under *Quality of the Idea*.
* **Distinct idea**: it separates **verified** evidence from **hypotheses** and never claims a test passed, which suits a voice assistant where overconfident spoken answers are a real risk.

What it is **not**: an Alexa skill, a device integration, or an MCP server. Do not describe it as any of these. Describe it as "a simulated Alexa+ style conversational experience".

## Remaining requirements checklist

Required by the rules:

- [ ] **Public GitHub repo** with all source, assets and setup/run instructions (README done). The MIT `LICENSE` file should make the license appear in the repo's About section; check that it does. (Alternative: private repo shared with the Amazon team, but public is simpler.)
- [ ] **Text description** of features and functionality (draft below).
- [ ] **Demo video, under 3 minutes**, public on YouTube or Vimeo, clearly showing the simulated experience running. No third-party trademarks (don't show Amazon, Alexa or GitHub logos prominently) and no unlicensed music. Script: `docs/DEMO.md`.
- [ ] **Product feedback for each tool, API or SDK used**: for each, what you used it for, what worked, what needs work, onboarding experience, and whether you'd build with it again (Yes/No with reasons). At minimum cover the **GitHub REST API**; add the **Anthropic API** only if you enable `ANTHROPIC_API_KEY` in the demo, and any AI coding tools you used to build this.
- [ ] **Select the track** (Alexa+) and any mini challenges on the form.
- [ ] Confirm **eligibility** (age of majority, not in an excluded region, not affiliated with Amazon/Devpost).

Mini challenges:

- [ ] **Open Source**: possible, since TraceLens is a new open-source project. The form asks for the contribution URL, project repo URL, your GitHub username, and a description of the work. Check the rules page for the exact window requirement (work must be made during the hackathon period, which opened Aug 31, 2026).
- [ ] **AWS Builder**: **not applicable.** TraceLens uses no AWS services. Don't claim it.

Optional:

- [ ] **Friction log / feature requests** (up to a 10% bonus in Stage Two scoring). If you ran into friction with the hackathon tools or APIs, write it down as you go.

Before you submit:

- [ ] Run the demo end to end with a real `GITHUB_TOKEN` and rehearse once (see `docs/DEMO.md`).
- [ ] `npm test` passes.
- [ ] Repo contains no secrets (`.env` is git-ignored; only `.env.example` is committed).

## Draft text description

> **TraceLens** is an evidence-first debugging agent with a simulated Alexa+ conversational experience. Tell it, by voice or text, which public GitHub repository is misbehaving and what the bug is (or paste an issue link). It collects the issue, comments, timeline, commits and diffs from GitHub, finds the change that fixed the bug when one exists, and ranks suspect commits by verifiable signals, most importantly whether a commit added lines the fix later removed. It builds a chronological investigation timeline and drafts a reproduction test.
>
> What makes it different is honesty: every statement is labelled **Verified** (observed in GitHub data, linked to its source), **Hypothesis** (a plausible explanation, rule-based or AI-written), or **Not run** (a suggested test that TraceLens never executes). Scores are heuristics, not probabilities, and the app never claims a test passed; you run it and record the real outcome. The assistant explains its rankings on request ("why is number 1 first?") and can read the summary aloud.
>
> Built with Node.js (zero dependencies), the GitHub REST API, and optionally the Anthropic API for hypothesis wording. Open source under MIT.
