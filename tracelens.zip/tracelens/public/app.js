'use strict';
// TraceLens frontend: a simulated Alexa+-style conversational assistant.
// All text that originates from GitHub is inserted via textContent (never innerHTML) to avoid XSS.

const $ = (s) => document.querySelector(s);
const log = $('#log'), input = $('#input'), sendBtn = $('#send'), orb = $('#orb'), orbLabel = $('#orb-label');
let config = { demo: null };
let state = { repoUrl: null, issueNumber: null, description: null, result: null, busy: false };

function h(tag, props = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') el.className = v; else if (k === 'text') el.textContent = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else if (v !== false && v != null) el.setAttribute(k, v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return el;
}
// Renders `inline code` segments safely
function rich(text) {
  const frag = document.createDocumentFragment();
  String(text).split(/(`[^`]+`)/g).forEach((p) => frag.append(p.startsWith('`') && p.endsWith('`') && p.length > 2 ? h('code', { text: p.slice(1, -1) }) : document.createTextNode(p)));
  return frag;
}
const fmtDate = (iso) => new Date(iso).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
const badge = (kind) => h('span', { class: `badge ${kind}`, text: { v: 'VERIFIED', h: 'HYPOTHESIS', n: 'NOT RUN' }[kind] });

// ---------- orb + voice ----------
function setOrb(mode, label) { orb.className = `orb ${mode}`; orbLabel.textContent = label; }
const synth = window.speechSynthesis;
function speak(text) {
  if (!$('#speak').checked || !synth) return;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text.replace(/`/g, ''));
  u.rate = 1.03; u.onstart = () => setOrb('speaking', 'Speaking…'); u.onend = () => setOrb('idle', 'Ready');
  synth.speak(u);
}
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null;
if (SR) {
  rec = new SR(); rec.lang = 'en-US'; rec.interimResults = false;
  rec.onresult = (e) => { input.value = e.results[0][0].transcript; submit(); };
  rec.onend = () => { $('#mic').classList.remove('on'); if (!state.busy) setOrb('idle', 'Ready'); };
  rec.onerror = () => { $('#mic').classList.remove('on'); setOrb('idle', 'Ready'); };
}
$('#mic').addEventListener('click', () => {
  if (!rec) return say('Voice input needs Chrome or Edge. You can type instead; everything works the same.');
  if (synth) synth.cancel();
  $('#mic').classList.add('on'); setOrb('listening', 'Listening…'); rec.start();
});

// ---------- chat helpers ----------
function scroll() { log.scrollTop = log.scrollHeight; }
function say(text, opts = {}) {
  const m = h('div', { class: 'msg bot' }, rich(text));
  log.append(m); scroll();
  if (opts.speak !== false) speak(text);
  return m;
}
function userSay(text) { log.append(h('div', { class: 'msg user', text })); scroll(); }
function suggest(items) {
  const box = $('#suggest'); box.replaceChildren();
  items.forEach(([label, text]) => box.append(h('button', { class: 'sg', type: 'button', onclick: () => { input.value = text; submit(); } }, label)));
}
const SUG_START = () => [['▶ Run the demo', 'run the demo'], ['What can you do?', 'help']];
const SUG_DONE = () => [['Why is #1 ranked first?', 'why is number 1 first'], ['Show timeline', 'show timeline'], ['Show repro test', 'show the repro test'], ['Read summary aloud', 'read it aloud'], ['New investigation', 'new investigation']];

// ---------- intent handling ----------
const GH_RE = /(?:https?:\/\/)?github\.com\/[\w.-]+\/[\w.-]+(?:\/(?:issues|pull)\/\d+)?/i;

function parseMessage(raw) {
  let t = raw.trim().replace(/^(hey |hi |ok |okay )?alexa[,:!]?\s*/i, '');
  return { t, low: t.toLowerCase(), url: (t.match(GH_RE) || [])[0] || null };
}

async function handle(raw) {
  const { t, low, url } = parseMessage(raw);
  if (!t) return;
  if (state.busy) return say('I am still investigating. One moment.');

  if (/^(run |start |try )?(the )?demo\b/.test(low)) return runDemo();
  if (/^(help|what can you do|how do(es)? this work)/.test(low)) return help();
  if (/(new|another|reset|start over|clear)( investigation)?$/.test(low) || low === 'reset') return reset();

  if (state.result && !url) {
    const r = state.result;
    if (/timeline|chronolog|history|when/.test(low)) { activate('timeline'); return say('Here is the investigation timeline. Every entry is a real event from GitHub; the role of the suspect commits is still a hypothesis.'); }
    if (/repro|test/.test(low)) { activate('repro'); return say(`I drafted a reproduction test (${r.reproTest.framework}). Status: **not run**. I never execute code, so nothing is confirmed until you run it and record the result.`.replace(/\*\*/g, '')); }
    if (/ledger|verified|proof|evidence summary|how sure|confiden/.test(low)) { activate('ledger'); return say(`I verified ${r.ledger.verifiedFacts} facts from GitHub, hold ${r.ledger.hypotheses} hypotheses, and have run ${r.ledger.testsRun} tests. Scores are heuristics, not probabilities.`); }
    if (/read|aloud|speak|summary|summarize|recap/.test(low)) { activate('suspects'); const was = $('#speak').checked; $('#speak').checked = true; say(r.spoken); $('#speak').checked = was; return; }
    if (/why|explain|how come|reason|rank/.test(low)) return explain(low);
    if (/suspect|result|top|root cause|show/.test(low)) { activate('suspects'); return say(r.spoken); }
  }

  // Slot filling: repo, issue, description
  if (url) {
    const m = url.match(/github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?(?:\/(?:issues|pull)\/(\d+))?$/i);
    state.repoUrl = `https://github.com/${m[1]}/${m[2]}`;
    state.issueNumber = m[3] ? Number(m[3]) : null;
    const rest = t.replace(GH_RE, '').replace(/^(please\s+)?(investigate|look (at|into)|debug|check|analy[sz]e)\s*/i, '').trim();
    if (rest.length > 12) state.description = rest;
  } else if (state.repoUrl && !state.description && !state.issueNumber) {
    state.description = t;
  } else if (!state.repoUrl) {
    return say('Which public GitHub repository should I look at? Paste a link like `https://github.com/owner/repo` (an issue link works too), or say "run the demo".');
  } else {
    state.description = t;
  }

  if (!state.repoUrl) return say('I need a GitHub repository link first.');
  if (!state.description && !state.issueNumber) {
    suggest([]);
    return say(`Got it, I'll use \`${state.repoUrl.replace('https://github.com/', '')}\`. What is the bug? Describe the symptom, error message, or paste a snippet. If you have an issue link, paste that instead.`);
  }
  return runInvestigation();
}

function help() {
  say('I\'m TraceLens. Give me a public GitHub repo and a bug description (or an issue link) and I will collect commits, diffs and issue details, rank likely root causes with evidence, build a timeline, and draft a reproduction test. I clearly separate what I verified from GitHub from what is only a hypothesis, and I never claim a test passed unless it was actually run. Try "run the demo".');
}
function reset() {
  state = { repoUrl: null, issueNumber: null, description: null, result: null, busy: false };
  $('#board').hidden = true; $('#board-empty').hidden = false; suggest(SUG_START());
  say('Okay, fresh start. Which repository should I investigate?');
}
function runDemo() {
  if (!config.demo) return say('Demo configuration is unavailable. Check that the server is running.');
  state = { ...state, repoUrl: config.demo.repoUrl, issueNumber: config.demo.issueNumber, description: config.demo.description, result: null };
  say(`Starting the demo: **${config.demo.title}**. This is a real public issue; I'll fetch it live from GitHub.`.replace(/\*\*/g, ''));
  return runInvestigation();
}

function explain(low) {
  const r = state.result;
  const m = low.match(/(?:number|#|rank|suspect)\s*(\d)/) || low.match(/\b(\d)\b/);
  const c = r.candidates[(m ? Number(m[1]) : 1) - 1] || r.candidates[0];
  if (!c) return say('I have no ranked suspects to explain for this investigation.');
  activate('suspects');
  const items = c.evidence.filter((e) => e.weight > 0).map((e) => `${e.text.replace(/\.$/, '')} (+${e.weight})`);
  say(`Suspect #${c.rank} is \`${c.shortSha}\` "${c.title}". Verified facts behind its score: ${items.join('; ') || 'none'}. ${c.hasProvenance ? 'The strongest signal is that it added lines the fix later removed.' : 'It has no removed-line match, so treat it as a weaker lead.'} Whether it is truly the root cause remains a hypothesis until a test shows it.`);
}

// ---------- investigation ----------
async function runInvestigation() {
  state.busy = true; sendBtn.disabled = true; suggest([]); setOrb('thinking', 'Investigating…');
  const stepsEl = h('ul', { class: 'steps' });
  log.append(h('div', { class: 'msg bot' }, h('div', { text: 'Collecting evidence from GitHub…' }), stepsEl)); scroll();
  const rows = new Map();
  const onStep = (s) => {
    let li = rows.get(s.id);
    if (!li) { li = h('li'); rows.set(s.id, li); stepsEl.append(li); }
    li.className = s.status === 'running' ? 'run' : s.status;
    li.replaceChildren(h('span', { class: 'ic' }), h('span', {}, s.label, s.detail ? h('span', { class: 'dt', text: ' · ' + s.detail }) : null)); scroll();
  };
  try {
    const res = await fetch('/api/investigate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ repoUrl: state.repoUrl, issueNumber: state.issueNumber, description: state.description || '' }) });
    if (!res.ok || !res.body) throw new Error(`Server returned ${res.status}`);
    const reader = res.body.getReader(), dec = new TextDecoder(); let buf = '', got = false;
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (!line) continue;
        const msg = JSON.parse(line);
        if (msg.type === 'step') onStep(msg);
        else if (msg.type === 'error') { got = true; failure(msg); }
        else if (msg.type === 'result') { got = true; success(msg.result); }
      }
    }
    if (!got) throw new Error('The server closed the connection without a result.');
  } catch (e) {
    failure({ message: e.message });
  } finally {
    state.busy = false; sendBtn.disabled = false; if (!orb.classList.contains('speaking')) setOrb('idle', 'Ready');
  }
}

function failure(msg) {
  const extra = msg.code === 'rate_limited' ? ' Add a GITHUB_TOKEN to .env (see README) and restart for a much higher limit.' : '';
  say(`I couldn't finish the investigation: ${msg.message}${extra}`);
  state.description = state.description; suggest(SUG_START());
}

function success(r) {
  state.result = r;
  $('#board-empty').hidden = true; $('#board').hidden = false;
  renderSuspects(r); renderTimeline(r); renderRepro(r); renderLedger(r);
  activate('suspects');
  say(r.spoken);
  if (r.meta.warnings.length) say('Heads up: ' + r.meta.warnings.join(' '), { speak: false });
  suggest(SUG_DONE());
  if (window.innerWidth <= 960) $('#board').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ---------- rendering ----------
function activate(tab) {
  document.querySelectorAll('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach((p) => (p.hidden = p.id !== `tab-${tab}`));
}
document.querySelectorAll('.tabs button').forEach((b) => b.addEventListener('click', () => activate(b.dataset.tab)));

function renderSuspects(r) {
  const p = $('#tab-suspects'); p.replaceChildren();
  const target = r.issue ? h('a', { href: r.issue.url, target: '_blank', rel: 'noopener', text: `${r.meta.owner}/${r.meta.repo}#${r.issue.number}` }) : `${r.meta.owner}/${r.meta.repo}`;
  p.append(h('div', { class: 'summary' },
    h('h3', {}, 'Investigation of ', target),
    h('p', { text: r.issue ? `“${r.issue.title}” · ${r.issue.state}` : r.description.slice(0, 200) }),
    h('p', {}, badge('v'), ` ${r.meta.mode === 'fix-anchored' ? 'A linked fix was found, so suspects are checked against the lines it removed.' : 'No linked fix found: ranking uses file, keyword and timing signals only (weaker).'}`),
    r.fix ? h('p', {}, 'Fix: ', h('a', { href: r.fix.url, target: '_blank', rel: 'noopener', text: r.fix.type === 'pull_request' ? `PR #${r.fix.number}` : r.fix.sha.slice(0, 7) }), ` ${r.fix.title}`) : null));
  r.meta.warnings.forEach((w) => p.append(h('div', { class: 'warnbox', text: w })));
  if (!r.candidates.length) p.append(h('div', { class: 'warnbox', text: 'No suspect scored above zero. Add a stack trace, file name or function name and try again.' }));
  r.candidates.forEach((c) => {
    const hy = c.hypothesis;
    p.append(h('article', { class: 'suspect' + (c.rank === 1 ? ' top' : '') },
      h('div', { class: 's-head' }, h('div', { class: 'rank', text: '#' + c.rank }),
        h('div', {}, h('div', { class: 's-title' }, h('a', { href: c.url, target: '_blank', rel: 'noopener', text: c.shortSha }), ' ', c.title),
          h('div', { class: 's-meta', text: `${c.author} · ${fmtDate(c.date)} · ${c.files.length} file(s)` }))),
      h('div', {}, h('div', { class: 'bar-label' }, h('span', { text: 'Heuristic evidence score (not a probability)' }), h('span', { text: `${c.score} pts · ${c.relativeScore}% of top` })), h('div', { class: 'bar' }, h('i', { style: `width:${Math.max(4, c.relativeScore)}%` }))),
      h('ul', { class: 'ev' }, c.evidence.map((e) => h('li', {}, e.weight > 0 ? badge('v') : h('span', { class: 'badge n', text: 'PENALTY' }), h('span', {}, rich(e.text)), h('span', { class: 'w', text: (e.weight > 0 ? '+' : '') + e.weight })))),
      h('div', { class: 'hypo' }, h('span', { class: 'lab' }, badge('h'), hy.source === 'llm' ? ' AI-generated hypothesis · unverified' : ' Rule-based hypothesis · unverified'), hy.text),
      h('details', {}, h('summary', { text: 'Files changed' }), h('div', { class: 'files', text: c.files.map((f) => `${f.filename} (+${f.additions}/−${f.deletions})`).join(' · ') }))));
  });
}

function renderTimeline(r) {
  const p = $('#tab-timeline'); p.replaceChildren(h('div', { class: 'summary' }, h('p', {}, badge('v'), ' Every event below is real GitHub data with a link. Suspect markers show real commits; calling one the root cause is a hypothesis.')));
  p.append(h('ol', { class: 'tl' }, r.timeline.map((e) => h('li', { class: e.kind === 'suspect' ? 'suspect-k' : e.kind },
    h('time', { text: fmtDate(e.ts) }), h('div', { class: 't' }, h('a', { href: e.url, target: '_blank', rel: 'noopener', text: e.title }), ' ', e.kind === 'suspect' ? badge('h') : badge('v')), e.detail ? h('div', { class: 'd', text: e.detail }) : null))));
}

function renderRepro(r) {
  const t = r.reproTest, p = $('#tab-repro'); p.replaceChildren();
  const key = `tl:${r.meta.owner}/${r.meta.repo}#${r.meta.issueNumber || 'x'}`;
  const saved = (() => { try { return JSON.parse(localStorage.getItem(key)); } catch { return null; } })();
  const rec = h('div', { class: 'summary' });
  const draw = (v) => {
    rec.replaceChildren(h('h3', {}, 'Record the real outcome'), h('p', { text: 'TraceLens cannot run code. After you run the test yourself, record what happened. This is user-reported and is shown that way.' }),
      h('div', { class: 'row' }, [['', 'Not run yet'], ['fails-suspect', 'Failed on suspect commit'], ['passes-suspect', 'Passed on suspect commit']].map(([val, lab]) => h('button', { class: 'btn' + ((v || '') === val ? ' sel' : ''), type: 'button', onclick: () => { try { localStorage.setItem(key, JSON.stringify(val)); } catch {} draw(val); } }, lab))),
      h('p', {}, v ? h('span', { class: 'badge h', text: 'USER-REPORTED' }) : badge('n'), ' ', v === 'fails-suspect' ? 'You reported the symptom reproduced on the suspect commit. Also check that it passes on the parent commit.' : v === 'passes-suspect' ? 'You reported it passed on the suspect commit; the hypothesis is not supported by this test.' : 'No test has been run.'));
  };
  draw(saved);
  p.append(
    h('div', { class: 'summary' }, h('p', {}, badge('n'), ` Suggested ${t.framework} test · ${t.basis}. TraceLens did not execute it.`)),
    h('pre', { class: 'code' }, h('code', { text: t.code })),
    h('div', { class: 'row' },
      h('button', { class: 'btn', type: 'button', onclick: (e) => { navigator.clipboard.writeText(t.code).then(() => { e.target.textContent = 'Copied ✓'; setTimeout(() => (e.target.textContent = 'Copy code'), 1500); }); } }, 'Copy code'),
      h('button', { class: 'btn', type: 'button', onclick: () => { const a = h('a', { href: URL.createObjectURL(new Blob([t.code], { type: 'text/plain' })), download: t.filename }); a.click(); } }, `Download ${t.filename}`)),
    h('div', { class: 'summary' }, h('h3', {}, 'How to run it'), h('ol', {}, t.instructions.map((s) => h('li', { text: s })))),
    rec);
}

function renderLedger(r) {
  const p = $('#tab-ledger'), g = r.meta.github; p.replaceChildren();
  p.append(
    h('div', { class: 'stats' },
      h('div', { class: 'stat v' }, h('b', { text: r.ledger.verifiedFacts }), h('span', { text: 'Verified facts from GitHub' })),
      h('div', { class: 'stat h' }, h('b', { text: r.ledger.hypotheses }), h('span', { text: `Hypotheses (${r.hypothesisSource === 'llm' ? 'AI-generated' : 'rule-based'}, unverified)` })),
      h('div', { class: 'stat n' }, h('b', { text: r.ledger.testsRun }), h('span', { text: 'Tests executed by TraceLens' })),
      h('div', { class: 'stat n' }, h('b', { text: r.ledger.testsPassed }), h('span', { text: 'Tests confirmed passing' }))),
    h('div', { class: 'summary' }, h('h3', {}, 'What was collected'), h('dl', { class: 'kv' },
      h('dt', { text: 'Mode' }), h('dd', { text: r.meta.mode === 'fix-anchored' ? 'Fix-anchored (strongest)' : 'Symptom-only (weaker)' }),
      h('dt', { text: 'Files examined' }), h('dd', { text: r.meta.filesExamined.join(', ') }),
      h('dt', { text: 'Commits in window' }), h('dd', { text: `${r.meta.commitsInWindow} (${r.meta.diffsAnalysed} diffs read)` }),
      h('dt', { text: 'Search window' }), h('dd', { text: `${r.meta.searchWindow.since ? fmtDate(r.meta.searchWindow.since) : 'start of history'} → ${fmtDate(r.meta.searchWindow.until)}` }),
      h('dt', { text: 'GitHub calls' }), h('dd', { text: `${g.calls} live, ${g.cacheHits} cached · ${g.authenticated ? 'authenticated' : 'unauthenticated'}${g.rateLimit ? ` · ${g.rateLimit.remaining}/${g.rateLimit.limit} left` : ''}` }),
      r.signals.errors.length ? [h('dt', { text: 'Errors in report' }), h('dd', { text: r.signals.errors.slice(0, 2).join(' | ') })] : null,
      r.signals.identifiers.length ? [h('dt', { text: 'Identifiers' }), h('dd', { text: r.signals.identifiers.join(', ') })] : null)),
    h('div', { class: 'summary' }, h('h3', {}, 'How to read this'), h('p', {}, badge('v'), ' means the fact was observed in GitHub data or computed from it (for example, a line added by this commit and removed by the fix).'),
      h('p', {}, badge('h'), ' means a plausible explanation that has not been proven.'), h('p', {}, badge('n'), ' means a test was suggested but never run by TraceLens. Scores rank leads; they are not probabilities of being right.')));
}

// ---------- boot ----------
function submit() {
  const text = input.value.trim(); if (!text) return;
  input.value = ''; userSay(text); handle(text);
}
$('#composer').addEventListener('submit', (e) => { e.preventDefault(); submit(); });
$('#speak').addEventListener('change', (e) => { if (!e.target.checked && synth) synth.cancel(); });

(async function init() {
  try { config = await (await fetch('/api/config')).json(); } catch { say('I can\'t reach the TraceLens server. Start it with `node server.js` and refresh.', { speak: false }); }
  $('#chip-gh').textContent = config.githubAuthenticated ? 'GitHub: token ✓' : 'GitHub: no token (60 req/hr)'; if (config.githubAuthenticated) $('#chip-gh').classList.add('good');
  $('#chip-ai').textContent = config.llmEnabled ? 'Hypotheses: AI + rules' : 'Hypotheses: rule-based'; if (config.llmEnabled) $('#chip-ai').classList.add('good');
  say('Hi, I\'m TraceLens. I investigate bugs in public GitHub repos and show my evidence, keeping what I verified separate from what I merely suspect. Paste a repository link, say "run the demo", or ask what I can do.', { speak: false });
  suggest(SUG_START());
})();
